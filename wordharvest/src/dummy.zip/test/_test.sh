#!/bin/bash
../bin/wordharvest -d ./ -o wordlist -e "txt:text:asc:doc" -v 1
../bin/bruteforce -l wordlist -f file.zip 
